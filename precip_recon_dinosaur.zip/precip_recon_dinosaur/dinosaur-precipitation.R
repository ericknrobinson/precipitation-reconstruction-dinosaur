#### Water year precip reconstruction for Dinosaur National Monument.
## Suggest using this script in the RStudio environment.

## Bring in needed libraries
library(dplR) ## version 1.6.8
library(plyr) ## version 1.8.4

setwd("/Users/justinderose/Documents/Research/Collaborators/JudsonFinley/CubCreek/analysis/public/")

## Bring in raw tree-ring data, detrend with spline, and check for EPS cut-off, and dating
rcb.d <- rwi.stats.running(detrend(read.rwl("rcb.rwl"), method=c("Spline")))
rcb.d ### good until -136
har.d <- rwi.stats.running(detrend(read.rwl("ut530.rwl"), method=c("Spline")))
har.d ### good until -295

## ARSTAN was used to generate Friedman detrended chronologies, read them in
har <- read.crn("har-res.txt"); har$year<-as.numeric(row.names(har))
rcb <- read.crn("rcb-res.txt"); rcb$year<-as.numeric(row.names(rcb))

################################################################################
## Tree-ring Response to Climate. 
## for the ut530 tree-ring data, see Knight et al. 2010
## Read in the PRISM climate data (latitude=40.5954, longitude=-109.0730, downloaded October 22, 2014)
prec <- read.csv("prec.csv") #dim(prec)=119,13
temp <- read.csv("temp.csv") #dim(temp)=119,13

library(treeclim) ## 2.0.0
# seascorr analysis (Meko et al. 2011), with precipitation as primary variable, temperature secondary.
scp <- seascorr(rcb, climate=list(prec, temp), season_lengths=c(1,3,6,12))
plot(scp) ## maximum correlation ending in July of 12 month cumulative

## Check for temporal stability of the relationship to precipitation
# toggle back and forth between last,first
resp <- dcc(rcb, prec, selection = -5:10, method = "response", 
            dynamic = "evolving", win_size = 30, win_offset = 5, 
            start_last = TRUE, timespan = NULL, ci = 0.05, boot = "std", sb = FALSE)
plot(resp) ## Plot indicates strong temporal fidelity 

## Calculate the dependent variable, 12 month August-July cumulative precipitation
library(zoo) ##1.8-2
## Take monthly precipitation data and calculate water year ending in July
## reshape into longitudinal format
long <- reshape(prec, idvar=c("year"), varying=list(2:13), direction="long", timevar="month", v.names="prec")
## sort them by year, month
sort.long <- long[order(long$year, long$month),]
## calculate the running, cumulative 12 month precipitation
run.12mt.p <- rollapply(sort.long$prec, 12, sum, fill=NA, align=c("right")) 
## put them back together in a dataframe
p.bind <-cbind(sort.long[,1:2], run.12mt.p); colnames(p.bind) <- c("year", "month", "prec")
## Subset out only the values for month 7 (July) (see seascorr analysis above)
dep <- subset(p.bind, p.bind$month==7)

################################################################################
## Precipitation Reconstruction Model
## combine full data set needed for reconstruction
lst <- list(har, rcb, dep)
full.dat <- join_all(lst, "year")
colnames(full.dat) <- c("har", "harN", "year", "rcb", "rcbN","month","prec" )
## Note: the object 'full.dat' will be used later for reconstruction data

### Subset the full data to the years of overlap between instrumental data and 
### tree-ring chronology end year (har=2005), That is 1920-2005
new.dat <- subset(full.dat, full.dat$year>=1920 & full.dat$year <=2005)

## Double check for any autocorrelation of predictors and dependent variable
acf(new.dat$har) ## none
acf(new.dat$rcb) ## none
acf(new.dat$prec) ## none

## Build the multiple regression model of Dinosaur N.M. Aug-July precipitation 
best.mod <- lm(prec ~ har + rcb, data=new.dat)
summary(best.mod) ## for model output
#R=0.5652, adjR=0.5547, df= 83, 
# 7.2188 + 4.375 * har + 6.8263 * rcb

### Full model evaluation:
### Residual plots, Q-Q plot, Leverage plot to evaluate assumptions:
plot(best.mod)

## Calculate root-mean-squared-error, rmse<-sqrt(mean((obs-pred)^2))
rmse <- sqrt(mean((new.dat$prec-best.mod$fitted.values)^2))  # 2.5029

### Check for autocorrelation in the residuals.
acf(best.mod$residuals)  ## no significant autocorrelation in residuals

### test for normality. null Hypothesis that residuals are = to normal. 
ks.test(best.mod$residuals, pnorm) ## p<-0.0000475.

## Double-check if residuals 'look' normal
hist(best.mod$residuals) ## Yes

### The Durban-Watson statistic is for assessing autocorrelation in the residuals
library(dcv) ## 0.1.1 
test.DW(new.dat$prec, best.mod$fitted)  
## DW = 2.23, dU = 1.416, dL=1.568, k=3 (including intercept), so at five percent 
## level look at Durbin-Watson tables in Savin and White (1977),
## 2.23 > 1.568 we can not reject the null (no autocorrelation) p=0.86

### Perform sign test 
### The available test needs standardized values (z-scores)
### significance of sign test indicated from Fritts (1976)
st <- test.ST((new.dat$prec - mean(new.dat$prec)) / sd(new.dat$prec), 
              (best.mod$fitted.values - mean(best.mod$fitted.values)) 
              / sd(best.mod$fitted.values))  ## 67/19, 78%

## Check for collinearity in multiple regression using variable inflation factor
library(HH) ## 3.1-35
vif(best.mod) # 1.567 is well below the recommendation of not exceeding ~4

################################################################################
### Model Calibration and Verification, two approaches

### Split Calibration, Early/Late ######
### Make a dataframe of predictors based on our new.dat data
cv.el <- as.data.frame(cbind(new.dat$year, new.dat$prec, new.dat$har, new.dat$rcb)) ## Note:1920-2005 (86)
colnames(cv.el) <- c("year", "prec", "har","rcb")

### Calibrate Model to 1920-1962 (Early) n=43
cv.el.early <- subset(cv.el, cv.el$year <= 1962)   ## subset to 1920-1962
cv.early.mod <- lm(prec ~ har + rcb, data = cv.el.early)	## rerun the model
summary(cv.early.mod) ## 8.886 + 4.660*har + 4.139*rcb
#R = 0.5316, adjR=0.5082, df=40

### Calibrate Model to 1963-2005 (Late) n=42
cv.el.late <- subset(cv.el, cv.el$year >= 1963)		## subset to 1963-2005
cv.late.mod <- lm(prec ~ har+rcb, data = cv.el.late)		## rerun the model
summary(cv.late.mod) ## 6.381 + 4.871*har + 7.756*rcb
# R=0.6207, adjR=0.6018, DF=40

### Reduction of Error statistic #########
prec.el.early <- mean(cv.el.early$prec)  
prec.el.late <- mean(cv.el.late$prec)    

### Sum-of-squared error, observed values
### Reduction of Error (RE) setup for the denominator in RE (Cook, 1999)
re.sse.early.ref <-sum((cv.el.early$prec - prec.el.late)^2)	
re.sse.late.ref <- sum((cv.el.late$prec - prec.el.early)^2)	  

### Predict maf late (verify) with early (calibrate) coefficients to calculate RE
### calibrate to 1921-1962
pred.late <- predict(cv.early.mod, cv.el.late)
sse.pred.late <- sum((cv.el.late$prec - pred.late)^2)  ## this is for the numerator in RE    
re.cal.early <- 1-(sse.pred.late/re.sse.late.ref)    	# RE: 0.5247
# Note denominator above is for mean of calibration data set (i.e., early)

### Predict maf early (verify) with late (calibrate) coefficients to calculate RE
### calibrate to 1963-2005
pred.early <- predict(cv.late.mod, cv.el.early)
sse.pred.early <- sum((cv.el.early$prec - pred.early)^2) ## this is for numerator in RE
re.cal.late <- 1-(sse.pred.early/re.sse.early.ref)			# RE: 0.471

### Coefficient of efficiency (CE), similar to RE, (Cook et al. 1999)
ce.sse.early.ref <- sum((cv.el.early$prec - prec.el.early)^2) # for the denominator
ce.sse.late.ref <- sum((cv.el.late$prec - prec.el.late)^2)    

### the numerator is the same as RE
### The CE will always be simlar to or less than the RE
ce.cal.early <- 1-(sse.pred.late/ce.sse.late.ref)     # CE: 0.4420
ce.cal.late <- 1-(sse.pred.early/ce.sse.early.ref)    # CE: 0.3210

### Split Calibration, Even/Odd ####
### Make a dataframe of predictors based on our new.dat data
cv.eo <- as.data.frame(cbind(new.dat$year, new.dat$prec, new.dat$har, new.dat$rcb)) 
colnames(cv.eo) <- c("year", "prec", "har","rcb")
cv.eo$eo <- rep(c("even","odd"),86/2) ## repeater for splitting into groups

### Calibrate Model to Even
cv.eo.even <- subset(cv.eo, cv.eo$eo == "even")   ## subset to even
cv.even.mod <- lm(prec ~ har+rcb, data = cv.eo.even)  ## rerun the model
summary(cv.even.mod) ## 8.358 + 4.465*har + 5.366*rcb
## R-0.564, adjR=0.542, DF=40

### Calibrate Model to Odd
cv.eo.odd <- subset(cv.eo, cv.eo$eo == "odd")		## subset to odd
cv.odd.mod <- lm(prec ~ har+rcb, data = cv.eo.odd)		## rerun the model
summary(cv.odd.mod) ## 5.828 + 3.768*har + 9.041*rcb
## R=0.576, adjR=0.555, DF=40

### Reduction of Error statistic #########
#### Average flows for periods 1921-1963 (early), 1964-2005 (late)
prec.eo.even <- mean(cv.eo.even$prec)   
prec.eo.odd <- mean(cv.eo.odd$prec)    

### Sum-of-squared error, observed values
### Reduction of Error (RE) setup for the denominator in RE (Cook et al. 1999)
re.sse.even.ref <-sum((cv.eo.even$prec - prec.eo.odd)^2)	# 
re.sse.odd.ref <- sum((cv.eo.odd$prec - prec.eo.even)^2)	#  

### Predict odd (verify) with even (calibrate) coefficients to calculate RE
pred.odd <- predict(cv.even.mod, cv.eo.odd)
sse.pred.odd <- sum((cv.eo.odd$prec - pred.odd)^2)  ## this is for the numerator in RE    
re.cal.even <- 1-(sse.pred.odd/re.sse.odd.ref)    	# RE: 0.558

### Predict even with odd coefficients to calculate RE
#pred.early <-  5.828 + 3.768*cvdat.early$har + 9.041*cvdat.early$rcb  
pred.even <- predict(cv.odd.mod, cv.eo.even)
sse.pred.even <- sum((cv.eo.even$prec - pred.even)^2) ## this is for numerator in RE
re.cal.odd <- 1-(sse.pred.even/re.sse.even.ref)			# RE: 0.526

### Coefficient of efficiency (CE), similar to RE, but...
ce.sse.even.ref <- sum((cv.eo.even$prec - prec.eo.even)^2) # for the denominator
ce.sse.odd.ref <- sum((cv.eo.odd$prec - prec.eo.odd)^2)    # 
### the numerator is the same as RE
### The CE will always be simlar to or less than the RE
ce.cal.even <- 1-(sse.pred.odd/ce.sse.odd.ref)     # CE: 0.533
ce.cal.odd <- 1-(sse.pred.even/ce.sse.even.ref)    # CE: 0.488

####################################################################################
### Apply the regression model to the full time-series, -110 to 2005
##  Use the 'full.dat' object from above 
full.dat$recon <- 7.2188 + 4.375 * full.dat$har + 6.8263 *full.dat$rcb
## Subset to the time-series acceptable for analysis. 
rec.dat <- subset(full.dat, full.dat$year >= -110)

## Calculate a 50-year and 100-year smoother for plotting
rec.dat$reclp50 <- ffcsaps(rec.dat$recon, nyrs=50)
rec.dat$reclp100 <- ffcsaps(rec.dat$recon, nyrs=100)

## Make a plot showing the relation ship between predictors and reconstruction
## for the instrumental time period (not in the paper)
par(cex=0.65, las=1)
plot(prec ~ year, data=rec.dat, xlim=c(1920,2005), ylim=c(5,30), type="l",
     col="darkgreen", lwd=2, ylab="August-July Precipitation (cm)", xlab="",
     main="")
abline(h=mean(rec.dat$prec, na.rm=T), col="darkgreen", lwd=2)
legend("bottomright","Precipitation",bty="n", lwd=2, col="darkgreen")
par(new=T)
plot(recon ~ year, data=rec.dat, xlim=c(1920,2005), ylim=c(5,30), type="l",
     col="darkblue", lwd=2, ylab="", xlab="")
abline(h=mean(rec.dat$recon, na.rm=T), col="darkblue", lwd=2)
legend("topleft","R-square = 0.55", bty="n")
legend("bottomleft","Reconstructed precipitation", bty="n", lwd=2, col="darkblue")

## Make a plot of the reconstruction for its full length
par(cex=0.65, las=1)
plot(recon ~ year, data=rec.dat, xlim=c(-110,2005), ylim=c(8,26), type="l",
     lwd=0.5, ylab="Precipitation (cm)", xlab="Year",
     main="")
abline(h=mean(rec.dat$prec, na.rm=T), lwd=2)
par(new=T)
plot(reclp50 ~ year, data=rec.dat, xlim=c(-110,2005), ylim=c(8,26), type="l",
     col="blue", lwd=4, ylab="", xlab="")
legend("bottomright","50-yr",bty="n",col="blue", lwd=4)
par(new=T)
plot(reclp100 ~ year, data=rec.dat, xlim=c(-110,2005), ylim=c(8,26), type="l",
     col="red", lwd=3, ylab="", xlab="")
legend("bottomleft","100-yr",bty="n",col="red", lwd=3)

#### Perform the wavelet analysis on the time-series
Yrs <- rec.dat$year
ts <- rec.dat$recon
out.wave <- morlet(y1 = ts, x1 = Yrs, p2 = 9, dj = 0.1, siglvl = 0.95)
levs <- quantile(out.wave$Power, probs = c(0, 0.5, 0.75, 0.9, 0.95))

## Plot the wavelet
wavelet.plot(out.wave, wavelet.levels = levs, add.sig = TRUE, add.spline=T,
             nyrs=25, f=0.5, crn.lab="Precipitation",
             key.cols = c("white", "green","blue","red"),
             useRaster = NA)

################################################################################
## Precipitation Variability Analysis 
## Calculate a 21-year running standard deviation on the reconstructed precipitation. 
library(gtools) ## 3.8.1
## Use changepoint to find significant shifts in mean running precipitation
library(changepoint) ## version 2.2.2

run.var <- running(rec.dat$recon, fun=var, align=c("center"), width=21) #
# n=2096 for width=21
yr.var <- seq(-100,1995,by=1)
var.dat <- as.data.frame(cbind(yr.var, run.var))
colnames(var.dat) <- c("year","runSD")

## Need a time-series object for changepoint that starts some time before 0
nts <- ts(var.dat$runSD, start=-100) ## 
rsd <- cpt.mean(nts, penalty="AIC",test.stat="Normal", method="PELT", Q=3 , minseglen=200)
## look at rsd object for mean 
rsd
rsd.means <- c(200,  424,  639, 1028, 1317, 1555, 1756) - 100 ### These are for Table 5.

#### Plot the rsd output. 
plot(rsd, ylab="Precip-SD (cm)", xlab="Year") 

######  ------ EOF  ------ ######
